<?php
return array (
  'cliSessionId' => '36f5b609e5c0a9c316ed05ccbaa2e6e7',
  'isInstalled' => true,
);
