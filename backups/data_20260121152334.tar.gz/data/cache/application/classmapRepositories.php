<?php
return [
  'ArrayValue' => 'Espo\\Repositories\\ArrayValue',
  'Attachment' => 'Espo\\Repositories\\Attachment',
  'Email' => 'Espo\\Repositories\\Email',
  'EmailAddress' => 'Espo\\Repositories\\EmailAddress',
  'EmailFolder' => 'Espo\\Repositories\\EmailFolder',
  'ExternalAccount' => 'Espo\\Repositories\\ExternalAccount',
  'Import' => 'Espo\\Repositories\\Import',
  'Integration' => 'Espo\\Repositories\\Integration',
  'Job' => 'Espo\\Repositories\\Job',
  'LayoutSet' => 'Espo\\Repositories\\LayoutSet',
  'PhoneNumber' => 'Espo\\Repositories\\PhoneNumber',
  'Portal' => 'Espo\\Repositories\\Portal',
  'Preferences' => 'Espo\\Repositories\\Preferences',
  'ScheduledJob' => 'Espo\\Repositories\\ScheduledJob',
  'Sms' => 'Espo\\Repositories\\Sms',
  'UniqueId' => 'Espo\\Repositories\\UniqueId',
  'User' => 'Espo\\Repositories\\User',
  'UserData' => 'Espo\\Repositories\\UserData',
  'Webhook' => 'Espo\\Repositories\\Webhook'
];
