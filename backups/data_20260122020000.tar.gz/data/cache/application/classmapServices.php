<?php
return [
  'Email' => 'Espo\\Services\\Email',
  'ExternalAccount' => 'Espo\\Services\\ExternalAccount',
  'Import' => 'Espo\\Services\\Import',
  'Integration' => 'Espo\\Services\\Integration',
  'Record' => 'Espo\\Services\\Record',
  'RecordTree' => 'Espo\\Services\\RecordTree',
  'Stream' => 'Espo\\Services\\Stream',
  'User' => 'Espo\\Services\\User'
];
