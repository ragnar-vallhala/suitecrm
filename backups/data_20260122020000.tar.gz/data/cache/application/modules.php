<?php
return [
  'Crm' => [
    'order' => 10,
    'jsTranspiled' => true
  ]
];
